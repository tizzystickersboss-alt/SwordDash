using UnityEngine;

public class EnemySpawner : MonoBehaviour
{
    [Header("Spawn Settings")]
    public GameObject enemyPrefab;
    public Transform spawnPoint; // Initial spawn position
    public float spawnInterval = 2f;  // Initial spawn delay
    public float spawnIntervalMin = 0.5f; // Minimum spawn interval
    public float spawnAcceleration = 0.01f; // How much interval decreases over time

    private float timer;

    void Update()
    {
        if (!GameManager.Instance.isGameActive) return;

        timer -= Time.deltaTime;
        if (timer <= 0f)
        {
            SpawnEnemy();
            timer = spawnInterval;

            // Gradually increase spawn rate
            spawnInterval = Mathf.Max(spawnIntervalMin, spawnInterval - spawnAcceleration);
        }
    }

    void SpawnEnemy()
    {
        GameObject enemy = Instantiate(enemyPrefab, spawnPoint.position, Quaternion.identity);

        // Optional: reset Z to 0 for 2D
        enemy.transform.position = new Vector3(enemy.transform.position.x, enemy.transform.position.y, 0);
    }
}
