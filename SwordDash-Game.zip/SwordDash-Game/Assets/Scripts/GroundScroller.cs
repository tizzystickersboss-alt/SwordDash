using UnityEngine;

public class GroundScroller : MonoBehaviour
{
    public float length = 20f; // Length of one ground segment
    private Transform mainCamera;

    void Start()
    {
        mainCamera = Camera.main.transform;
    }

    void Update()
    {
        if (!GameManager.Instance.isGameActive) return;

        transform.position += Vector3.left * GameManager.Instance.scrollSpeed * Time.deltaTime;

        if (Camera.main.transform.position.x - transform.position.x > length)
        {
            MoveForward();
        }
    }


    void MoveForward()
    {
        transform.position += Vector3.right * length * 2f;
    }

}
