using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
public class Enemy : MonoBehaviour
{
    [Header("Movement")]
    public float moveSpeed = 3f;

    private Transform player;
    private Rigidbody2D rb;

    void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player")?.transform;
        rb = GetComponent<Rigidbody2D>();
    }

    void Update()
    {
        if (!GameManager.Instance.isGameActive || player == null) return;

        // Move toward player horizontally
        Vector2 direction = (player.position - transform.position).normalized;
        rb.linearVelocity = new Vector2(direction.x * moveSpeed, rb.linearVelocity.y);
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            // Optional: trigger shake on collision
            Camera.main.GetComponent<CameraFollow>()?.Shake(0.2f, 0.2f);

            // Player death handled in PlayerController
        }
        else if (collision.gameObject.CompareTag("Obstacle"))
        {
            // Stop enemy on obstacle if desired
            rb.linearVelocity = Vector2.zero;
        }
    }
}
