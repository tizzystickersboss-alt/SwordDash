using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    [Header("Follow Settings")]
    public float smoothSpeed = 5f;
    public Vector3 offset = new Vector3(2f, 1f, -10f);

    [Header("Zoom Settings")]
    public float zoomAmount = 2f;     // Zoom in amount
    public float zoomSpeed = 2f;      // Zoom interpolation speed

    [Header("Shake Settings")]
    public float shakeDuration = 0.3f;
    public float shakeMagnitude = 0.2f;

    private Transform player;
    private Camera cam;
    private float defaultSize;
    private float targetSize;
    private bool isShaking = false;
    private Vector3 shakeOffset;

    void Start()
    {
        cam = GetComponent<Camera>();
        defaultSize = cam.orthographicSize;
        targetSize = defaultSize;
        FindPlayer();
    }

    void LateUpdate()
    {
        if (!GameManager.Instance.isGameActive) return;

        if (player == null)
        {
            FindPlayer();
            return;
        }

        // Smooth follow
        Vector3 targetPos = new Vector3(player.position.x, player.position.y, 0) + offset + shakeOffset;
        transform.position = Vector3.Lerp(transform.position, targetPos, smoothSpeed * Time.deltaTime);

        // Smooth zoom
        cam.orthographicSize = Mathf.Lerp(cam.orthographicSize, targetSize, zoomSpeed * Time.deltaTime);
    }

    void FindPlayer()
    {
        if (GameManager.Instance != null && GameManager.Instance.isGameActive)
        {
            GameObject p = GameObject.FindGameObjectWithTag("Player");
            if (p != null)
                player = p.transform;
        }
    }

    // Zoom methods
    public void ZoomIn() => targetSize = defaultSize - zoomAmount;
    public void ResetZoom() => targetSize = defaultSize;

    // Shake methods
    public void Shake(float durationOverride = -1f, float magnitudeOverride = -1f)
    {
        if (!isShaking)
            StartCoroutine(DoShake(durationOverride, magnitudeOverride));
    }

    private System.Collections.IEnumerator DoShake(float durationOverride, float magnitudeOverride)
    {
        isShaking = true;
        float duration = (durationOverride > 0) ? durationOverride : shakeDuration;
        float magnitude = (magnitudeOverride > 0) ? magnitudeOverride : shakeMagnitude;

        float elapsed = 0f;

        while (elapsed < duration)
        {
            float offsetX = Random.Range(-1f, 1f) * magnitude;
            float offsetY = Random.Range(-1f, 1f) * magnitude;
            shakeOffset = new Vector3(offsetX, offsetY, 0);

            elapsed += Time.unscaledDeltaTime;
            yield return null;
        }

        shakeOffset = Vector3.zero;
        isShaking = false;
    }
}
