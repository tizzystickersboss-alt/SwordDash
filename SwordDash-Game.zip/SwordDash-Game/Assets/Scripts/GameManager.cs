﻿using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using System.Collections;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance;

    [Header("References")]
    public GameObject playerPrefab;
    public Transform spawnPoint;
    private GameObject playerInstance;
    public Camera mainCamera;

    [Header("UI Prefabs")]
    public GameObject menuPanelPrefab;
    public GameObject gameOverPanelPrefab;

    private GameObject menuPanelInstance;
    private GameObject gameOverPanelInstance;
    private Image fadeOverlay;

    [Header("Game Settings")]
    public float scrollSpeed = 5f;
    public bool isGameActive = false;

    private float score = 0f;
    private bool showMenuOnLoad = false;

    void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
            SceneManager.sceneLoaded += OnSceneLoaded;
        }
        else
        {
            Destroy(gameObject);
        }
    }

    void Start()
    {
        isGameActive = false;
        Time.timeScale = 0f;

        SpawnUI();
        CreateFadeOverlay();

        // ✅ Always show menu on startup
        if (menuPanelInstance != null)
            menuPanelInstance.SetActive(true);

        StartCoroutine(FadeIn());
    }

    void Update()
    {
        if (isGameActive)
        {
            ScrollCamera();
            score += Time.deltaTime * scrollSpeed;
        }

        if (Input.GetKeyDown(KeyCode.R))
            RestartGame();
    }

    void ScrollCamera()
    {
        if (mainCamera == null)
        {
            mainCamera = Camera.main;
            if (mainCamera == null) return;
        }

        mainCamera.transform.position += Vector3.right * scrollSpeed * Time.deltaTime;
    }

    public void StartGame()
    {
        StartCoroutine(StartGameSequence());
    }

    private IEnumerator StartGameSequence()
    {
        yield return StartCoroutine(FadeOut());

        isGameActive = true;
        score = 0f;

        if (playerInstance != null)
            Destroy(playerInstance);

        playerInstance = Instantiate(playerPrefab, spawnPoint.position, Quaternion.identity);

        if (menuPanelInstance != null) menuPanelInstance.SetActive(false);
        if (gameOverPanelInstance != null) gameOverPanelInstance.SetActive(false);

        Time.timeScale = 1f;

        yield return StartCoroutine(FadeIn());

        Debug.Log("🎮 Game Started!");
    }

    public void StopMovement()
    {
        isGameActive = false;
        scrollSpeed = 0f;

        if (playerInstance != null)
        {
            Rigidbody2D rb = playerInstance.GetComponent<Rigidbody2D>();
            if (rb != null)
                rb.linearVelocity = Vector2.zero;
        }

        Debug.Log("Movement stopped!");
    }

    public void RestartGame()
    {
        showMenuOnLoad = true;
        StartCoroutine(SceneReloadSequence());
    }

    private IEnumerator SceneReloadSequence()
    {
        yield return StartCoroutine(FadeOut());
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

    public void GameOver()
    {
        if (!isGameActive) return;
        isGameActive = false;
        Debug.Log("💀 Game Over! Final Score: " + Mathf.RoundToInt(score));
        StartCoroutine(GameOverSequence());
    }

    private IEnumerator GameOverSequence()
    {
        float slowMoFactor = 0.2f;
        float deathDelay = 1f;
        float gameOverScreenTime = 2f;

        Time.timeScale = slowMoFactor;
        yield return new WaitForSecondsRealtime(deathDelay);

        Time.timeScale = 1f;

        if (gameOverPanelInstance != null)
            gameOverPanelInstance.SetActive(true);

        yield return new WaitForSecondsRealtime(gameOverScreenTime);

        yield return StartCoroutine(FadeOut());

        showMenuOnLoad = true;
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

    private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        StartCoroutine(HandleSceneLoad());
    }

    private IEnumerator HandleSceneLoad()
    {
        yield return null;

        mainCamera = Camera.main;
        spawnPoint = GameObject.FindWithTag("SpawnPoint")?.transform;

        SpawnUI();
        CreateFadeOverlay();

        // ✅ Always show menu after reload
        if (showMenuOnLoad)
        {
            showMenuOnLoad = false;
            if (menuPanelInstance != null)
            {
                menuPanelInstance.SetActive(true);
                Time.timeScale = 0f;
            }
        }
        else
        {
            if (menuPanelInstance != null)
            {
                menuPanelInstance.SetActive(true);
                Time.timeScale = 0f;
            }
        }

        yield return StartCoroutine(FadeIn());
    }

    private void SpawnUI()
    {
        Canvas canvas = FindOrCreateCanvas();

        // Clean up previous UI
        if (menuPanelInstance != null) Destroy(menuPanelInstance);
        if (gameOverPanelInstance != null) Destroy(gameOverPanelInstance);

        // Spawn Menu
        if (menuPanelPrefab != null)
        {
            menuPanelInstance = Instantiate(menuPanelPrefab, canvas.transform);
            menuPanelInstance.SetActive(false);

            // ✅ Automatically connect Start button
            UnityEngine.UI.Button startButton = menuPanelInstance.GetComponentInChildren<UnityEngine.UI.Button>();
            if (startButton != null)
            {
                startButton.onClick.RemoveAllListeners();
                startButton.onClick.AddListener(() =>
                {
                    Debug.Log("✅ Start button pressed!");
                    StartGame();
                });
            }
            else
            {
                Debug.LogWarning("⚠️ No Button found in Menu Panel prefab!");
            }
        }

        // Spawn Game Over Panel
        if (gameOverPanelPrefab != null)
        {
            gameOverPanelInstance = Instantiate(gameOverPanelPrefab, canvas.transform);
            gameOverPanelInstance.SetActive(false);
        }
    }


    private Canvas FindOrCreateCanvas()
    {
        Canvas canvas = FindObjectOfType<Canvas>();
        if (canvas == null)
        {
            GameObject canvasGO = new GameObject("Canvas");
            canvas = canvasGO.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvasGO.AddComponent<CanvasScaler>();
            canvasGO.AddComponent<GraphicRaycaster>();
        }
        return canvas;
    }

    private void CreateFadeOverlay()
    {
        Canvas canvas = FindOrCreateCanvas();

        if (fadeOverlay != null)
            Destroy(fadeOverlay.gameObject);

        GameObject fadeGO = new GameObject("FadeOverlay");
        fadeGO.transform.SetParent(canvas.transform, false);

        fadeOverlay = fadeGO.AddComponent<Image>();
        fadeOverlay.color = new Color(0, 0, 0, 1);

        RectTransform rt = fadeOverlay.GetComponent<RectTransform>();
        rt.anchorMin = Vector2.zero;
        rt.anchorMax = Vector2.one;
        rt.offsetMin = Vector2.zero;
        rt.offsetMax = Vector2.zero;

        // ✅ Always keep fade overlay on top
        fadeOverlay.transform.SetAsLastSibling();
    }

    private IEnumerator FadeOut(float duration = 1f)
    {
        if (fadeOverlay == null) yield break;

        float elapsed = 0f;
        Color c = fadeOverlay.color;

        while (elapsed < duration)
        {
            if (fadeOverlay == null) yield break; // safety check
            elapsed += Time.unscaledDeltaTime;
            float alpha = Mathf.Lerp(0f, 1f, elapsed / duration);
            fadeOverlay.color = new Color(c.r, c.g, c.b, alpha);
            yield return null;
        }

        if (fadeOverlay != null)
            fadeOverlay.color = new Color(c.r, c.g, c.b, 1f);
    }

    private IEnumerator FadeIn(float duration = 1f)
    {
        if (fadeOverlay == null) yield break;

        float elapsed = 0f;
        Color c = fadeOverlay.color;

        while (elapsed < duration)
        {
            if (fadeOverlay == null) yield break; // safety check
            elapsed += Time.unscaledDeltaTime;
            float alpha = Mathf.Lerp(1f, 0f, elapsed / duration);
            fadeOverlay.color = new Color(c.r, c.g, c.b, alpha);
            yield return null;
        }

        if (fadeOverlay != null)
            fadeOverlay.color = new Color(c.r, c.g, c.b, 0f);
    }

}
