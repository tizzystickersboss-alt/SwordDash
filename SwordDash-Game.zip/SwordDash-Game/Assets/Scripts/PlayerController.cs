using UnityEngine;
using UnityEngine.InputSystem;

[RequireComponent(typeof(Rigidbody2D))]
[RequireComponent(typeof(Animator))]
public class PlayerController : MonoBehaviour
{
    [Header("Movement Settings")]
    public float moveSpeed = 5f;
    public float jumpForce = 10f;
    public LayerMask groundLayer;

    [Header("Combat Settings")]
    public float attackCooldown = 0.4f;
    public Transform attackPoint;
    public float attackRange = 0.5f;
    public LayerMask enemyLayer;
    public int attackVariations = 3;

    private Rigidbody2D rb;
    private Animator anim;
    private bool isGrounded;
    private bool canAttack = true;

    // Input
    private PlayerControls controls;
    private bool jumpPressed = false;
    private bool attackPressed = false;

    void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();

        controls = new PlayerControls();

        // Input System Bindings
        controls.Gameplay.Jump.performed += ctx => jumpPressed = true;
        controls.Gameplay.Attack.performed += ctx => attackPressed = true;
    }

    void OnEnable() => controls.Gameplay.Enable();
    void OnDisable() => controls.Gameplay.Disable();

    void Update()
    {
        if (!GameManager.Instance.isGameActive) return;

        // Auto-move forward
        rb.linearVelocity = new Vector2(moveSpeed, rb.linearVelocity.y);

        // Check grounded using a more reliable raycast
        isGrounded = Physics2D.Raycast(transform.position, Vector2.down, 1f, groundLayer);

        // Jump
        if (jumpPressed && isGrounded)
        {
            Jump();
        }

        // Attack
        if (canAttack && attackPressed)
        {
            Attack();
        }

        jumpPressed = false;
        attackPressed = false;

        UpdateAnimations();
    }

    void Jump()
    {
        rb.linearVelocity = new Vector2(rb.linearVelocity.x, jumpForce);
        anim.SetTrigger("Jump");
    }

    void Attack()
    {
        canAttack = false;
        int randomAttack = Random.Range(1, attackVariations + 1);
        anim.SetTrigger("Attack" + randomAttack);

        // Detect enemies in range
        Collider2D[] hitEnemies = Physics2D.OverlapCircleAll(attackPoint.position, attackRange, enemyLayer);
        foreach (Collider2D enemy in hitEnemies)
        {
            Destroy(enemy.gameObject);
        }

        Invoke(nameof(ResetAttack), attackCooldown);
    }

    void ResetAttack() => canAttack = true;

    void UpdateAnimations()
    {
        anim.SetBool("IsGrounded", isGrounded);
       /* anim.SetFloat("VerticalSpeed", rb.linearVelocity.y);
        anim.SetFloat("Speed", Mathf.Abs(moveSpeed));*/
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Obstacle"))
        {
            anim.SetTrigger("Death");
            GameManager.Instance.GameOver();
        }
    }

    void OnDrawGizmosSelected()
    {
        if (attackPoint == null) return;
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(attackPoint.position, attackRange);
    }
}
